# No.87 Windows reproduction | PowerShell 5.1 | Python 3.10+
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$log = Join-Path $root 'NO87_WINDOWS_LOG.txt'
$src = Join-Path $root 'NO87_WINDOWS_VERIFY.py'
$utf8 = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($log, '', $utf8)
function Log([string]$line) {
    Write-Host $line
    [System.IO.File]::AppendAllText($log, $line + [Environment]::NewLine, $utf8)
}
try {
    Log 'NO87 WINDOWS REPRODUCTION START'
    Log ('UTC: ' + [DateTime]::UtcNow.ToString('o'))
    Log ('OS: ' + [Environment]::OSVersion.VersionString)
    Log ('PowerShell: ' + $PSVersionTable.PSVersion.ToString())
    $payload = 'ZnJvbSBjb2xsZWN0aW9ucyBpbXBvcnQgQ291bnRlciwgZGVxdWUKZnJvbSBpdGVydG9vbHMgaW1wb3J0IGNvbWJpbmF0aW9ucwpmcm9tIG1hdGggaW1wb3J0IGNvbWIKZnJvbSByYW5kb20gaW1wb3J0IFJhbmRvbQoKZGVmIGFtYmllbnQobik6CiAgICBmYWNlcz1bXQogICAgZm9yIGZyZWUgaW4gcmFuZ2UoMTw8bik6CiAgICAgICAgcmVzdD0oKDE8PG4pLTEpXmZyZWU7IGJvdHRvbT1yZXN0CiAgICAgICAgd2hpbGUgVHJ1ZToKICAgICAgICAgICAgbWFzaz0wOyBzPWZyZWUKICAgICAgICAgICAgd2hpbGUgVHJ1ZToKICAgICAgICAgICAgICAgIG1hc2sgfD0gMTw8KGJvdHRvbXxzKQogICAgICAgICAgICAgICAgaWYgbm90IHM6IGJyZWFrCiAgICAgICAgICAgICAgICBzPShzLTEpJmZyZWUKICAgICAgICAgICAgZmFjZXMuYXBwZW5kKChtYXNrLGZyZWUuYml0X2NvdW50KCksYm90dG9tLmJpdF9jb3VudCgpKSkKICAgICAgICAgICAgaWYgbm90IGJvdHRvbTogYnJlYWsKICAgICAgICAgICAgYm90dG9tPShib3R0b20tMSkmcmVzdAogICAgYXNzZXJ0IGxlbihmYWNlcyk9PTMqKm4KICAgIHJldHVybiBmYWNlcwoKZGVmIGNoZWNrKG4sZmFtaWx5LGZhY2VzKToKICAgIFY9e3YgZm9yIHYgaW4gcmFuZ2UoMTw8bikgaWYgZmFtaWx5Pj52JjF9CiAgICBhY3R1YWw9Q291bnRlcigpCiAgICBmb3IgbWFzayxrLGQgaW4gZmFjZXM6CiAgICAgICAgaWYgZmFtaWx5Jm1hc2s9PW1hc2s6IGFjdHVhbFtrLGRdKz0xCiAgICBwcmVkaWN0ZWQ9Q291bnRlcigpOyBkZWZlY3RzPUNvdW50ZXIoKTsgcm9vdHM9c2V0KCkKICAgIGZvciB2IGluIFY6CiAgICAgICAgZG93bj1bMTw8aSBmb3IgaSBpbiByYW5nZShuKSBpZiB2JigxPDxpKSBhbmQgdl4oMTw8aSkgaW4gVl0KICAgICAgICB3LHI9di5iaXRfY291bnQoKSxsZW4oZG93bikKICAgICAgICBpZiBub3Qgcjogcm9vdHMuYWRkKHYpCiAgICAgICAgZm9yIGsgaW4gcmFuZ2UocisxKTogcHJlZGljdGVkW2ssdy1rXSs9Y29tYihyLGspCiAgICAgICAgZm9yIGEsYiBpbiBjb21iaW5hdGlvbnMoZG93biwyKToKICAgICAgICAgICAgaWYgdl5hXmIgbm90IGluIFY6IGRlZmVjdHNbMix3LTJdKz0xCiAgICBhc3NlcnQgYWN0dWFsLmtleXMoKTw9cHJlZGljdGVkLmtleXMoKSBhbmQgYWxsKGFjdHVhbFtrZXldPD12YWwgZm9yIGtleSx2YWwgaW4gcHJlZGljdGVkLml0ZW1zKCkpCiAgICBkaWZmPXByZWRpY3RlZC1hY3R1YWwKICAgIGFzc2VydCBDb3VudGVyKHtrZXk6dmFsIGZvciBrZXksdmFsIGluIGRpZmYuaXRlbXMoKSBpZiBrZXlbMF09PTJ9KT09ZGVmZWN0cwogICAgYXNzZXJ0IChhY3R1YWw9PXByZWRpY3RlZCk9PShub3QgZGVmZWN0cykKICAgIGlmIG5vdCBkZWZlY3RzOgogICAgICAgIHVuc2Vlbj1zZXQoVik7IGNvbXBvbmVudHM9MAogICAgICAgIHdoaWxlIHVuc2VlbjoKICAgICAgICAgICAgY29tcG9uZW50cys9MTsgdj1uZXh0KGl0ZXIodW5zZWVuKSk7IHVuc2Vlbi5yZW1vdmUodik7IHE9W3ZdOyBjb21wb25lbnQ9e3Z9CiAgICAgICAgICAgIGZvciB1IGluIHE6CiAgICAgICAgICAgICAgICBmb3IgaSBpbiByYW5nZShuKToKICAgICAgICAgICAgICAgICAgICB6PXVeKDE8PGkpCiAgICAgICAgICAgICAgICAgICAgaWYgeiBpbiB1bnNlZW46IHVuc2Vlbi5yZW1vdmUoeik7IHEuYXBwZW5kKHopOyBjb21wb25lbnQuYWRkKHopCiAgICAgICAgICAgIHJyPWNvbXBvbmVudCZyb290czsgYXNzZXJ0IGxlbihycik9PTEKICAgICAgICAgICAgcm9vdD1uZXh0KGl0ZXIocnIpKTsgZGlzdD17cm9vdDowfTsgcXVldWU9ZGVxdWUoW3Jvb3RdKQogICAgICAgICAgICB3aGlsZSBxdWV1ZToKICAgICAgICAgICAgICAgIHU9cXVldWUucG9wbGVmdCgpCiAgICAgICAgICAgICAgICBmb3IgaSBpbiByYW5nZShuKToKICAgICAgICAgICAgICAgICAgICB6PXVeKDE8PGkpCiAgICAgICAgICAgICAgICAgICAgaWYgeiBpbiBjb21wb25lbnQgYW5kIHogbm90IGluIGRpc3Q6IGRpc3Rbel09ZGlzdFt1XSsxOyBxdWV1ZS5hcHBlbmQoeikKICAgICAgICAgICAgYXNzZXJ0IGFsbCh2JnJvb3Q9PXJvb3QgYW5kIGRpc3Rbdl09PSh2XnJvb3QpLmJpdF9jb3VudCgpIGZvciB2IGluIGNvbXBvbmVudCkKICAgICAgICBhc3NlcnQgc3VtKCgtMSkqKmsqYyBmb3IgKGssZCksYyBpbiBhY3R1YWwuaXRlbXMoKSk9PWNvbXBvbmVudHMKICAgIHJldHVybiBub3QgZGVmZWN0cwoKZGVmIG1haW4oKToKICAgIHRvdGFsPXJvb3RlZD0wCiAgICBmb3IgbiBpbiByYW5nZSg1KToKICAgICAgICBmYWNlcz1hbWJpZW50KG4pOyB5ZXM9cm9vdF95ZXM9MAogICAgICAgIGZvciBmYW1pbHkgaW4gcmFuZ2UoMSwxPDwoMTw8bikpOgogICAgICAgICAgICBvaz1jaGVjayhuLGZhbWlseSxmYWNlcyk7IHllcys9b2sKICAgICAgICAgICAgaWYgZmFtaWx5JjE6IHJvb3RfeWVzKz1vawogICAgICAgIGNvdW50PSgxPDwoMTw8bikpLTE7IHJvb3RfY291bnQ9KGNvdW50KzEpLy8yOyB0b3RhbCs9Y291bnQ7IHJvb3RlZCs9cm9vdF9jb3VudAogICAgICAgIHByaW50KGYnbj17bn0gbm9uZW1wdHk9e2NvdW50fSBwYXNzPXt5ZXN9IGZhaWw9e2NvdW50LXllc30gcm9vdGVkPXtyb290X2NvdW50fSByb290ZWRfcGFzcz17cm9vdF95ZXN9IHJvb3RlZF9mYWlsPXtyb290X2NvdW50LXJvb3RfeWVzfScsZmx1c2g9VHJ1ZSkKICAgIHByaW50KGYnRVhIQVVTVElWRSBub25lbXB0eT17dG90YWx9IHJvb3RlZD17cm9vdGVkfSBtaXNtYXRjaGVzPTAnLGZsdXNoPVRydWUpCiAgICBybmc9UmFuZG9tKDg3MjAyNikKICAgIGZvciBuIGluIHJhbmdlKDUsOSk6CiAgICAgICAgZmFjZXM9YW1iaWVudChuKTsgeWVzPTAKICAgICAgICBmb3IgdHJpYWwgaW4gcmFuZ2UoMjAwKToKICAgICAgICAgICAgaWYgdHJpYWwlMz09MDoKICAgICAgICAgICAgICAgIHA9cm5nLmNob2ljZShbMC4wNSwwLjIsMC41LDAuOCwwLjk1XSk7IGZhbWlseT1zdW0oMTw8diBmb3IgdiBpbiByYW5nZSgxPDxuKSBpZiBybmcucmFuZG9tKCk8cCkgb3IgMQogICAgICAgICAgICBlbHNlOgogICAgICAgICAgICAgICAgZ2VuZXJhdG9ycz1bcm5nLnJhbmRyYW5nZSgxPDxuKSBmb3IgXyBpbiByYW5nZShybmcucmFuZHJhbmdlKDEsOSkpXTsgc2hpZnQ9cm5nLnJhbmRyYW5nZSgxPDxuKSBpZiB0cmlhbCUzPT0yIGVsc2UgMAogICAgICAgICAgICAgICAgZmFtaWx5PXN1bSgxPDx2IGZvciB2IGluIHJhbmdlKDE8PG4pIGlmIGFueSgoKHZec2hpZnQpJmcpPT0odl5zaGlmdCkgZm9yIGcgaW4gZ2VuZXJhdG9ycykpCiAgICAgICAgICAgIHllcys9Y2hlY2sobixmYW1pbHksZmFjZXMpCiAgICAgICAgcHJpbnQoZidSQU5ET00gbj17bn0gc2FtcGxlcz0yMDAgcGFzcz17eWVzfSBmYWlsPXsyMDAteWVzfSBtaXNtYXRjaGVzPTAnLGZsdXNoPVRydWUpCiAgICBmYW1pbHk9c3VtKDE8PHYgZm9yIHYgaW4gWzAsNCw2LDcsM10pOyBhc3NlcnQgbm90IGNoZWNrKDMsZmFtaWx5LGFtYmllbnQoMykpCiAgICBhc3NlcnQgQ291bnRlcih7KGssZCk6c3VtKGZhbWlseSZtPT1tIGZvciBtLGEsYiBpbiBhbWJpZW50KDMpIGlmIChhLGIpPT0oayxkKSkgZm9yIF8sayxkIGluIGFtYmllbnQoMyl9KVsoMiwwKV09PTAKICAgIHByaW50KCdQNSBjb3VudGVyZXhhbXBsZTogQyh4KT01KzR4LCBDKC0xKT0xLCBzcXVhcmUgY29uZGl0aW9uIGZhbHNlJykKICAgIHByaW50KCdBTEwgUEFTUycpCmlmIF9fbmFtZV9fPT0nX19tYWluX18nOiBtYWluKCkK'
    [System.IO.File]::WriteAllBytes($src, [Convert]::FromBase64String($payload))
    $actualHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $src).Hash.ToLowerInvariant()
    Log ('Source SHA256: ' + $actualHash)
    if ($actualHash -cne '35505dda5d0fae67c8615b81d9473ba1b496101cd5d2dd11927cd9d84d2285d9') { throw 'Source SHA256 mismatch' }
    Log 'SOURCE SHA256 PASS'
    $exe = $null
    $prefix = @()
    foreach ($name in @('py.exe','python.exe')) {
        $cmd = Get-Command $name -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
        if (-not $cmd) { continue }
        $candidatePrefix = @()
        if ($name -eq 'py.exe') { $candidatePrefix = @('-3') }
        try {
            $probe = & $cmd.Source @candidatePrefix '-c' 'import sys; print(sys.version.split()[0]); sys.exit(0 if sys.version_info >= (3,10) else 1)' 2>$null
            if ($LASTEXITCODE -eq 0 -and $probe) {
                $exe = $cmd.Source; $prefix = $candidatePrefix; $version = $probe; break
            }
        } catch { continue }
    }
    if (-not $exe) { throw 'Python 3.10 or newer was not found' }
    Log ('Python: ' + $version)
    Log ('Executable: ' + $exe)
    $env:PYTHONOPTIMIZE = ''
    $timer = [Diagnostics.Stopwatch]::StartNew()
    $lines = New-Object 'System.Collections.Generic.List[string]'
    $ErrorActionPreference = 'Continue'
    & $exe @prefix '-u' $src 2>&1 | ForEach-Object {
        $line = $_.ToString()
        $lines.Add($line)
        Log $line
    }
    $code = $LASTEXITCODE
    $ErrorActionPreference = 'Stop'
    $timer.Stop()
    Log ('Python exit code: ' + $code)
    Log ('Elapsed seconds: ' + $timer.Elapsed.TotalSeconds.ToString('F3',[Globalization.CultureInfo]::InvariantCulture))
    if ($code -ne 0) { throw 'Python verification failed' }
    $expected = @'
n=0 nonempty=1 pass=1 fail=0 rooted=1 rooted_pass=1 rooted_fail=0
n=1 nonempty=3 pass=3 fail=0 rooted=2 rooted_pass=2 rooted_fail=0
n=2 nonempty=15 pass=14 fail=1 rooted=8 rooted_pass=8 rooted_fail=0
n=3 nonempty=255 pass=182 fail=73 rooted=128 rooted_pass=109 rooted_fail=19
n=4 nonempty=65535 pass=20969 fail=44566 rooted=32768 rooted_pass=14507 rooted_fail=18261
EXHAUSTIVE nonempty=65809 rooted=32907 mismatches=0
RANDOM n=5 samples=200 pass=133 fail=67 mismatches=0
RANDOM n=6 samples=200 pass=121 fail=79 mismatches=0
RANDOM n=7 samples=200 pass=115 fail=85 mismatches=0
RANDOM n=8 samples=200 pass=109 fail=91 mismatches=0
P5 counterexample: C(x)=5+4x, C(-1)=1, square condition false
ALL PASS
'@
    $normalized = ($lines.ToArray() -join "`n").Trim()
    $expected = ($expected -replace "`r`n", "`n").Trim()
    if ($normalized -cne $expected) { throw 'Reference output mismatch; inspect log' }
    Log 'REFERENCE OUTPUT EXACT MATCH'
    Log 'NO87_WINDOWS_FINAL PASS'
    exit 0
} catch {
    Log ('ERROR: ' + $_.Exception.Message)
    Log 'NO87_WINDOWS_FINAL FAIL'
    exit 1
}
