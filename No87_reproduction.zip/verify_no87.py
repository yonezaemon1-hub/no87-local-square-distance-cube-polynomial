from collections import Counter, deque
from itertools import combinations
from math import comb
from random import Random

def ambient(n):
    faces=[]
    for free in range(1<<n):
        rest=((1<<n)-1)^free; bottom=rest
        while True:
            mask=0; s=free
            while True:
                mask |= 1<<(bottom|s)
                if not s: break
                s=(s-1)&free
            faces.append((mask,free.bit_count(),bottom.bit_count()))
            if not bottom: break
            bottom=(bottom-1)&rest
    assert len(faces)==3**n
    return faces

def check(n,family,faces):
    V={v for v in range(1<<n) if family>>v&1}
    actual=Counter()
    for mask,k,d in faces:
        if family&mask==mask: actual[k,d]+=1
    predicted=Counter(); defects=Counter(); roots=set()
    for v in V:
        down=[1<<i for i in range(n) if v&(1<<i) and v^(1<<i) in V]
        w,r=v.bit_count(),len(down)
        if not r: roots.add(v)
        for k in range(r+1): predicted[k,w-k]+=comb(r,k)
        for a,b in combinations(down,2):
            if v^a^b not in V: defects[2,w-2]+=1
    assert actual.keys()<=predicted.keys() and all(actual[key]<=val for key,val in predicted.items())
    diff=predicted-actual
    assert Counter({key:val for key,val in diff.items() if key[0]==2})==defects
    assert (actual==predicted)==(not defects)
    if not defects:
        unseen=set(V); components=0
        while unseen:
            components+=1; v=next(iter(unseen)); unseen.remove(v); q=[v]; component={v}
            for u in q:
                for i in range(n):
                    z=u^(1<<i)
                    if z in unseen: unseen.remove(z); q.append(z); component.add(z)
            rr=component&roots; assert len(rr)==1
            root=next(iter(rr)); dist={root:0}; queue=deque([root])
            while queue:
                u=queue.popleft()
                for i in range(n):
                    z=u^(1<<i)
                    if z in component and z not in dist: dist[z]=dist[u]+1; queue.append(z)
            assert all(v&root==root and dist[v]==(v^root).bit_count() for v in component)
        assert sum((-1)**k*c for (k,d),c in actual.items())==components
    return not defects

def main():
    total=rooted=0
    for n in range(5):
        faces=ambient(n); yes=root_yes=0
        for family in range(1,1<<(1<<n)):
            ok=check(n,family,faces); yes+=ok
            if family&1: root_yes+=ok
        count=(1<<(1<<n))-1; root_count=(count+1)//2; total+=count; rooted+=root_count
        print(f'n={n} nonempty={count} pass={yes} fail={count-yes} rooted={root_count} rooted_pass={root_yes} rooted_fail={root_count-root_yes}',flush=True)
    print(f'EXHAUSTIVE nonempty={total} rooted={rooted} mismatches=0',flush=True)
    rng=Random(872026)
    for n in range(5,9):
        faces=ambient(n); yes=0
        for trial in range(200):
            if trial%3==0:
                p=rng.choice([0.05,0.2,0.5,0.8,0.95]); family=sum(1<<v for v in range(1<<n) if rng.random()<p) or 1
            else:
                generators=[rng.randrange(1<<n) for _ in range(rng.randrange(1,9))]; shift=rng.randrange(1<<n) if trial%3==2 else 0
                family=sum(1<<v for v in range(1<<n) if any(((v^shift)&g)==(v^shift) for g in generators))
            yes+=check(n,family,faces)
        print(f'RANDOM n={n} samples=200 pass={yes} fail={200-yes} mismatches=0',flush=True)
    family=sum(1<<v for v in [0,4,6,7,3]); assert not check(3,family,ambient(3))
    assert Counter({(k,d):sum(family&m==m for m,a,b in ambient(3) if (a,b)==(k,d)) for _,k,d in ambient(3)})[(2,0)]==0
    print('P5 counterexample: C(x)=5+4x, C(-1)=1, square condition false')
    print('ALL PASS')
if __name__=='__main__': main()
