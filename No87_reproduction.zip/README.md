# No.87 — reproducibility package

Copyright 2026 Ryutaro Yonezu. All rights reserved.
NOT HUMAN PEER REVIEWED. NOVELTY INCONCLUSIVE. REFERENCES PARTIAL.

Author verification assets are unchanged from v0.4. `verification.log` is the baseline; `WINDOWS_LOG_USER_TRANSCRIPT.txt` is author-supplied evidence, not an independent Windows audit. The separate private AI audit reports PASS for the mathematical proofs, reproduction, independent calculations and sampled collapse sequences. The author script does not explicitly test collapse sequences. The editorial publication candidate has not been independently re-audited. No independent audit source files are redistributed in this package.

Python 3.12.10, standard library only. Do not use `-O` or set `PYTHONOPTIMIZE`, because the checks use assertions.

Linux/macOS: `python3 verify_no87.py > actual.log` then `diff -u verification.log actual.log`.
Windows PowerShell: `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\NO87_WINDOWS_VERIFY.ps1`.
The PowerShell wrapper embeds the original script, checks its hash and compares expected output. Expected final line: `NO87_WINDOWS_FINAL PASS`.

65,809 nonempty sets (n=0..4) plus 800 seeded trials (n=5..8), zero mismatches. PASS/FAIL per dimension refers to the mathematical identity being true/false, not test failures. See the paper for exact scope and the proofs.
